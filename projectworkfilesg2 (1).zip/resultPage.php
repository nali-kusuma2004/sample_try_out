<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Results page</title>
    <link rel="stylesheet" href="resultPage.css">
<style>
.body{ background:purple;}
.b{
 width:130px;
    height: 40px;
    background-color:white;
    box-shadow:10px  white;
    border-radius: 5px;
   margin-left: 45%;
align:center;
}
</style>
</head>
<body class="body">
   
        <div class="header">
         
         <div class="header_nav">
            <img src="logo1.jpeg">
            <p>SAMPLE TRY-OUT</p>
         </div>
                <ul class="nav">
                    <li ><a href="#" id="home">Home</a></li>
                    <li ><a href="coreSubjectTest.html">Tests</a></li>
                    <li ><a href="contact.html">Contact</a></li>
                    <li ><a href="login.html">login</a></li>
                    <li ><a href="signup.html">signup</a></li>
                </ul>
          
            </div>

    
    <div class="hello">
       


        <table class="results-table" border="1px" bgcolor="white" style="padding:40px">
            <tr style="padding:10px">
                <th>Subjects</th>
                <th>Questions</th>
                <th>Marks obtained</th>
            </tr>
            <tr>
                <td>
                    Maths
                </td>
                <td>
                    50
                </td>
                <td>
                    2
                </td>
              
            </tr>
            <tr>
                <td>
                    Physics
                </td>
                <td>
                    25
                </td>
                <td>
                    -
                </td>
            </tr>
            <tr>
                <td>
                    Chemistry
                </td>
                <td>
                    25
                </td>
                <td>
                    -
                </td>
            </tr>
            <tr>
                <td>
                    Core subjects
                </td>
                <td>
                    100
                </td>
                <td>
                    -
                </td>
            </tr>
            <tr>
                <td>
                    Total
                </td>
                <td>
                    200
                </td>
                <td>
                    2
                </td>
                
            </tr>
        </table>
    </div><br><br><br><br>

<div>
<h4 style="color:white; text-align:center;">THANK YOU FOR YOUR ATTEMPT ,ATTEMPT AGAIN</h4>
<button class="b" ><a href="HOMEPAGE.HTML">logout</a></button>
</div>
</body>
</html>
