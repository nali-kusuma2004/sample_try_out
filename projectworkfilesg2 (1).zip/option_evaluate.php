<?php
include 'conn.php';
include 'insert2.php';
session_start();
echo $select;







?>
