
<?php 
include 'conn.php';
$sql='select * from question_maths where ques_id=11';
$res=mysqli_query($conn,$sql);
if(mysqli_num_rows($res))
{
while($row=mysqli_fetch_assoc($res))
{
$x1="{$row['question']}";$x11_1="{$row['option_1']}";$x11_2="{$row['option_2']}";
$x11_3="{$row['option_3']}";$x11_4="{$row['option_4']}";
}
}?> 
<?php 
include 'conn.php';
$sql='select * from question_maths where ques_id=12';
$res=mysqli_query($conn,$sql);
if(mysqli_num_rows($res))
{
while($row=mysqli_fetch_assoc($res))
{
$x12="{$row['question']}";$x12_1="{$row['option_1']}";$x12_2="{$row['option_2']}";
$x12_3="{$row['option_3']}";$x12_4="{$row['option_4']}";
}

}?> <?php 
include 'conn.php';
$sql='select * from question_maths where ques_id=13';
$res=mysqli_query($conn,$sql);
if(mysqli_num_rows($res))
{
while($row=mysqli_fetch_assoc($res))
{
$x13="{$row['question']}";$x13_1="{$row['option_1']}";$x13_2="{$row['option_2']}";
$x13_3="{$row['option_3']}";$x13_4="{$row['option_4']}";
}

}?> 

<?php 
include 'conn.php';
$sql='select * from question_maths where ques_id=14';
$res=mysqli_query($conn,$sql);
if(mysqli_num_rows($res))
{
while($row=mysqli_fetch_assoc($res))
{
$x14="{$row['question']}";$x14_1="{$row['option_1']}";$x14_2="{$row['option_2']}";
$x14_3="{$row['option_3']}";$x14_4="{$row['option_4']}";
}

}?> 

<?php 
include 'conn.php';
$sql='select * from question_maths where ques_id=15';
$res=mysqli_query($conn,$sql);
if(mysqli_num_rows($res))
{
while($row=mysqli_fetch_assoc($res))
{
$x15="{$row['question']}";$x15_1="{$row['option_1']}";$x15_2="{$row['option_2']}";
$x15_3="{$row['option_3']}";$x15_4="{$row['option_4']}";
}

}?> 

<?php 
include 'conn.php';
$sql='select * from question_maths where ques_id=16';
$res=mysqli_query($conn,$sql);
if(mysqli_num_rows($res))
{
while($row=mysqli_fetch_assoc($res))
{
$x16="{$row['question']}";$x16_1="{$row['option_1']}";$x16_2="{$row['option_2']}";
$x16_3="{$row['option_3']}";$x16_4="{$row['option_4']}";
}
}?> 
<?php 
include 'conn.php';
$sql='select * from question_maths where ques_id=17';
$res=mysqli_query($conn,$sql);
if(mysqli_num_rows($res))
{
while($row=mysqli_fetch_assoc($res))
{
$x17="{$row['question']}";$x17_1="{$row['option_1']}";$x17_2="{$row['option_2']}";
$x17_3="{$row['option_3']}";$x17_4="{$row['option_4']}";
}

}?> <?php 
include 'conn.php';
$sql='select * from question_maths where ques_id=18';
$res=mysqli_query($conn,$sql);
if(mysqli_num_rows($res))
{
while($row=mysqli_fetch_assoc($res))
{
$x18="{$row['question']}";$x18_1="{$row['option_1']}";$x18_2="{$row['option_2']}";
$x18_3="{$row['option_3']}";$x18_4="{$row['option_4']}";
}

}?> 

<?php 
include 'conn.php';
$sql='select * from question_maths where ques_id=19';
$res=mysqli_query($conn,$sql);
if(mysqli_num_rows($res))
{
while($row=mysqli_fetch_assoc($res))
{
$x19="{$row['question']}";$x19_1="{$row['option_1']}";$x19_2="{$row['option_2']}";
$x19_3="{$row['option_3']}";$x19_4="{$row['option_4']}";
}

}?> 

<?php 
include 'conn.php';
$sql='select * from question_maths where ques_id=20';
$res=mysqli_query($conn,$sql);
if(mysqli_num_rows($res))
{
while($row=mysqli_fetch_assoc($res))
{
$x20="{$row['question']}";$x20_1="{$row['option_1']}";$x20_2="{$row['option_2']}";
$x20_3="{$row['option_3']}";$x20_4="{$row['option_4']}";
}

}?> 
